import { Router } from 'express';
import Producto from '../models/Producto';

const router = Router();


export default router;
